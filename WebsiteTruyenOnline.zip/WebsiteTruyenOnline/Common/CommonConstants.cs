﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebsiteTruyenOnline.Common
{
    public static class CommonConstants
    {
        public static string ADMIN_SESSION = "ADMIN_SESSION";
        public static string USER_SESSION = "USER_SESSION";
    }
}